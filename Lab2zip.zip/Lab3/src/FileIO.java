import java.io.*;
import java.util.*;
import java.util.*
;public class FileIO {
	private String fname = null;
	private boolean DEBUG = true; //good touch in code to turn on or off printing by setting to false

	public FileIO(String fname) {
		this.fname = fname;
	}

	public Franchise readData() { //read data method, extensive operation, returns franchise
		Franchise a1 = null;
		int counter = 0; //counter for number of lines read
		try {            //try block, if there is any error in block, goes immediately to catch
			FileReader file = new FileReader(fname); //create new file
			BufferedReader buff = new BufferedReader(file); //allows file to be buffered for efficient reading of long files 
			String temp; 
			boolean eof = false; //eof happens when there is no more line to read, line = null
			while (!eof) { 
				String line = buff.readLine(); //read file into the buffer
				counter++; //increment counter, 1st line, 2nd line... so forth
				if (line == null) //when there is no more lines to read
					eof = true; //the end of file is true
				else { //else
					if (DEBUG)
						System.out.println("Reading" + line);
					if (counter == 1) { //salesdat.txt first line is number of stores - 6
						temp = line;
						a1 = new Franchise(Integer.parseInt(temp)); //so make it array size of 6
						if (DEBUG)
							System.out.println("d  " + a1.numberofstores());
					}
					if (counter == 2) //just a header, because file begins to show info
						;
					if (counter > 2) { //begin to read the rest of the lines
						  	int x = buildStore(a1, (counter-3), line); //build a store to read text files, store class structure is a 2d array, populate array here, counter - 3 bc info starts on the third line, x is # weeks of data
							if (DEBUG) //can turn on or off anyt ime
								System.out.println("Reading Store # "+(counter-2)+" Number of weeks read =  " +  x); //print weeks
							if (DEBUG) //can turn on or off any time to see if any errors
							{	
								System.out.println("Data read:");
								a1.getStores(counter-3).printdata(); //print out stores
							}
					}
				}
			}
			buff.close();
		} catch (Exception e) { //catch if there is any errors
			System.out.println("Error -- " + e.toString());
		}
		return a1;
	}

	public int buildStore(Franchise a1, int counter, String temp) { //build store
		Store tstore = new Store();
		String s1  =  ""; //saving values, initialize
		float sale = 0.0f; //value converted from string to float, when reading data everything is a string
		int week = 0; //part of 2d array
		int day = 0; //part of 2d array
		StringTokenizer st = new StringTokenizer(temp); //temp is one line of money data, this helps chop the arrays into more efficient smaller chunks - lab 5, chops string into 35 units
	    while (st.hasMoreTokens()) { //while there is more lines(temp), go ahead and get more data and parse
	         for(day=0;day<7;day++) //look at every seven data(one week)
	         {
		    	 s1 = st.nextToken(); //nexttoken() will get value from stream + take it out, ex. if i have values in array 1,2,3,4,5, first column will bring 1, next 2, next 3, so forth
		         sale = Float.parseFloat(s1); //convert to float values
	        	 tstore.setsaleforweekdayintersection(week, day, sale); //set values to the array
	         }
	         week++; //increment week
	    }
		a1.setStores(tstore, counter); //once store is built up there^^, set store in franchise
	    return week; //return should be five weeks of data
	}
}
