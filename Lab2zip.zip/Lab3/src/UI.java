import java.util.Scanner;
public class UI {

    public static void main(String[] args) {
    	{
       	 // TODO Auto-generated method stub
       	FileIO a1 = new FileIO("/Users/jasonvu/Downloads/assignment336b/src/Salesdat.txt");
   		Franchise f = a1.readData();
           Scanner sc = new Scanner(System.in);
           System.out.printf("Welcome to the Chick-Fila Franchise App! %nWe have data for six store locations for the last 5 weeks.");
           System.out.printf("%n1. San Jose %n2. Sunnyvale  %n3. Milpitas %n4. Fremont  %n5. Santa Clara %n6. San Francisco %n");
           int user = 1;
           while(user == 1) { //allows user to quit whenever
           	System.out.printf("\n");
           System.out.println("Which store number would you like to see the analystics for?");
           System.out.println( "Please enter the store number: ");
           int storeNum = sc.nextInt();
        
           System.out.printf("%n1. TOTAL SALE FOR WEEK %n2. AVERAGE DAILY SALE %n3. TOTAL SALE FOR ALL WEEKS %n4. AVERAGE WEEKLY SALES %n5. HIGHEST WEEK SALES %n6. LOWEST WEEK SALES ");
        System.out.printf("%n 7. ALL INFORMATION %n8. PRINT SALES DATA");
        System.out.printf("\n");
        System.out.println("Enter the number of which operation you want to calculate.");
        int op = sc.nextInt();
       
        f.getStores(storeNum).print(op);

        System.out.printf("%nPress 1 to CONTINUE viewing information %n2 to QUIT");
        user = sc.nextInt();
        }
           sc.close(); 
   }
        
 } 
    public void play() {
    	 // TODO Auto-generated method stub
    	FileIO a1 = new FileIO("/Users/jasonvu/Downloads/assignment336b/src/Salesdat.txt");
		Franchise f = a1.readData();
        Scanner sc = new Scanner(System.in);
        System.out.printf("Welcome to the Chick-Fila Franchise App! %nWe have data for six store locations for the last 5 weeks.");
        System.out.printf("%n1. San Jose %n2. Sunnyvale  %n3. Milpitas %n4. Fremont  %n5. Santa Clara %n6. San Francisco %n");
        int user = 1;
        while(user == 1) { //allows user to quit whenever
        	System.out.printf("\n");
        System.out.println("Which store number would you like to see the analystics for?");
        System.out.println( "Please enter the store number: ");
        int storeNum = sc.nextInt();
     
        System.out.printf("%n1. TOTAL SALE FOR WEEK %n2. AVERAGE DAILY SALE %n3. TOTAL SALE FOR ALL WEEKS %n4. AVERAGE WEEKLY SALES %n5. HIGHEST WEEK SALES %n6. LOWEST WEEK SALES ");
     System.out.printf("%n 7. ALL INFORMATION %n8. PRINT SALES DATA");
     System.out.printf("\n");
     System.out.println("Enter the number of which operation you want to calculate.");
     int op = sc.nextInt();
    
     f.getStores(storeNum).print(op);

     System.out.printf("%nPress 1 to CONTINUE viewing information %n2 to QUIT");
     user = sc.nextInt();
     if(user == 2) { System.out.println("PROGRAM HAS QUIT");
     }
        
        sc.close(); 
        }
} }