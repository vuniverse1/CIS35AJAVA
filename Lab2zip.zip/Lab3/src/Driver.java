
public class Driver {

public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileIO a1 = new FileIO("/Users/jasonvu/Downloads/assignment336b/src/Salesdat.txt");
		Franchise f = a1.readData();
		f.calc();
		UI ui = new UI();
	ui.play();

		//f.getStores(1).print(5);
	}



}
