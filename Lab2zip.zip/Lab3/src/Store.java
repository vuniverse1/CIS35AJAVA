
public class Store {
	private float salesbyweek[][];
	
	Store() {
		salesbyweek = new float[5][7];
	}

	// getter and setters
	// setsaleforweekdayintersection(int week, int day, float sale)
	public void setsaleforweekdayintersection(int week, int day, float sale) {
		salesbyweek[week][day] = sale;
	}

	public void printdata() {
		for (int i = 0; i < 5; i++)
		{
			for (int j = 0; j < 7; j++)
			{
				System.out.print("$" + salesbyweek[i][j] + " ");
			}
			System.out.println("");
		}
	}
	//business methods
	public void calcTotalSalesForWeek() {
		float sale;
		
		for(int i = 0; i < 5; i++) {
			sale = 0;
		for(int j = 0; j < 7; j++) {
			
			sale +=  salesbyweek[i][j];
			}
		System.out.printf("$%5.2f\n", sale);
		
		}
		System.out.printf("\n");
	}
		
	public void calcAvgSalesForWeek() {
			float sale;
			float average;
			
			for(int i = 0; i < 5; i++) {
			
				sale = 0;
			for(int j = 0; j < 7; j++) {
				
				sale +=  (salesbyweek[i][j]);
				}
			average = sale/7;
			System.out.printf("$%5.2f\n", average);
			
			}
			System.out.printf("\n");}
		
	public void calcTotalSalesForAllWeeks() {
		float sale = 0;
		for(int i = 0; i< 5; i++) {
			for(int j = 0; j < 7; j++) {
				sale += salesbyweek[i][j];
			}
	}	System.out.printf("$%5.2f\n", sale);
	System.out.printf("\n");}
	
	 public void calcAvgWeeklySales() {
		 float sale = 0;
			for(int i = 0; i< 5; i++) {
				for(int j = 0; j < 7; j++) {
					sale += salesbyweek[i][j];
				}
		}	System.out.printf("$%5.2f\n", sale/5);
		System.out.printf("\n");}
	 
	public void calcWeekWithHighestSaleAmt() {
		float sale[] = new float[5];
		float max=0;
		int wk=0;
			for(int i = 0; i< 5; i++) {
				sale[i] = 0; 
				for(int j = 0; j < 7; j++) {
					sale[i] += salesbyweek[i][j];
						}
				sale[0] = max;
				for(int x = 0; x<sale.length; x++) {
					if(max<sale[x]) {
						max = sale[x];
						wk = x;
					}
				}
				
			
				
		} System.out.printf("Week %d\n",wk + 1);
		System.out.printf("\n");
	}
	public void calcWeekWithLowestSaleAmt() {
		float sale[] = new float[5];
		float min = 0;
		int wk = 0;
			for(int i = 0; i< 5; i++) {
				sale[i] = 0; 
				for(int j = 0; j < 7; j++) {
					sale[i] += salesbyweek[i][j];
						}
				sale[0] = min;
				for(int x = 0; x<sale.length; x++) {
					if(min>sale[x]) {
						min = sale[x];
						wk = x;
					}
				}
				
			
				
		} System.out.printf("Week %d\n",wk + 1);
		System.out.printf("\n");
	}
	public void analyzeresults() { // analyzeresults //call a through f
		calcTotalSalesForWeek();
		calcAvgSalesForWeek();
		calcTotalSalesForAllWeeks();
		calcAvgWeeklySales();
		calcWeekWithHighestSaleAmt();
		calcWeekWithLowestSaleAmt();
	}
	
	public void print(int num) {  //switch statements
		
		switch(num){
		case 1: calcTotalSalesForWeek();
			break;
			
		case 2: calcAvgSalesForWeek();
			break;
			
		case 3: calcTotalSalesForAllWeeks();
			break;
			
		case 4: calcAvgWeeklySales();
			break;
			
		case 5: calcWeekWithHighestSaleAmt();
			break;
			
		case 6: calcWeekWithLowestSaleAmt();
			break;
			
		case 7:
			calcTotalSalesForWeek();
			calcAvgSalesForWeek();
			calcTotalSalesForAllWeeks();
			calcAvgWeeklySales();
			calcWeekWithHighestSaleAmt();
			calcWeekWithLowestSaleAmt();
		
			break;
		case 8: printdata();
		break;} } 
			
}

			
		


		
		
	

